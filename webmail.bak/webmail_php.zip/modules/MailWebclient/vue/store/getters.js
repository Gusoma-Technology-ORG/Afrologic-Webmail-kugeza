export function getServersByTenants (state) {
  return state.serversByTenants
}
