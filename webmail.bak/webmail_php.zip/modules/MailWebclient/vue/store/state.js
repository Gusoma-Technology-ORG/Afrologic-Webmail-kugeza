export default function () {
  return {
    serversByTenants: {},
  }
}
