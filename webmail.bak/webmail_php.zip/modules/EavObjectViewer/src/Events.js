import Vue from 'vue';

export default {
  EventBus: new Vue(),
};
