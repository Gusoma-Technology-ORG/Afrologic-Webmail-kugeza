# Aurora Core module
System module that provides core functionality such as User management, Tenants management.

# License
This module is licensed under AGPLv3 license if free version of the product is used or Afterlogic Software License if commercial version of the product was purchased.
